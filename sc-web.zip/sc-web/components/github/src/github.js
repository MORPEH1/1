var Github = Github || { version: "0.1.0" };
