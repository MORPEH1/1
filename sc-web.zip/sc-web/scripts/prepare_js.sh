python concatenate_js.py ../client/js/ ../client/static/components/js/sc-web-core.js $1
