sudo apt-get install python-pip
sudo pip install tornado sqlalchemy redis==2.9
