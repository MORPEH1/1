$.namespace('SCWeb.ui');
