$.namespace('SCWeb.core');
